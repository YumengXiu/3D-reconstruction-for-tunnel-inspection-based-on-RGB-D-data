#ifndef HASH_INCLUDED
#define HASH_INCLUDED
#include <unordered_map>
#define hash_map std::unordered_map
#endif // HASH_INCLUDED
